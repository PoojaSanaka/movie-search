app.service('getFilmDetails',['$http',function($http){	
		this.result = null;
		this.filmData = function(query){
			this.jsonData = JSON.stringify([{title : "Beauty and the beast",description : "fairy tale",image_url : "../image/beauty.jpg",Actors:"Emma Watson",Director:"Bill Condon",Writer: "Stephen chbosky",Language:"English", Awards:"Best Fantasy Movie"},{title : "Thor",description : "Supper hero movie",image_url : "../image/Thor.jpg",Actors:"Chris Hemsworth",Director:"Kenneth Branag",Writer: "Ashley Edward Miller",Language:"English", Awards:"Best Fantasy Movie"},{title : "Iron man",description : "Supper hero movie",image_url : "../image/ironman.jpg",Actors:"Robert Downey Jr.",Director:"Jon Favreau",Writer: "Mark Fergus",Language:"English", Awards:"Best Fantasy Movie"}]);
			this.data = JSON.parse(this.jsonData);
			for(item in this.data){
				if(this.data[item].title.includes(query)){
					this.result = this.data[item];
				}
			}
			
		}
	
	
}]),
app.controller("MovieController",['$scope','getFilmDetails','$location','$route',function($scope,getFilmDetails,$location,$route){
	$scope.searchApi=function(){
		getFilmDetails.filmData($scope.query);
		$location.url('/showResult');
		$route.reload();
		}
	}]),
app.controller("ShowController",["$scope","getFilmDetails",function($scope,getFilmDetails){
	$scope.thisMovie={};
	if(getFilmDetails.result != undefined || getFilmDetails.result != null ){
		$scope.thisMovieNotfound = false;
		$scope.thisMovie = getFilmDetails.result;
	}else{
		$scope.thisMovieNotfound = true;
	}
}]);
