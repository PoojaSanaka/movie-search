app.config(["$routeProvider",function(l){
	l.when("/",{templateUrl:"partials/home.html"}).when("/showResult",{templateUrl:"partials/show.html",controller:"ShowController"})}]);
