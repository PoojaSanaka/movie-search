When a user enters a movie title into the search box and clicks the search button, make an API call to search for movies using the user input.  Then, display all the search results on the same page.

Home page:
  - Input box for user to enter movie title.
  - When the user clicks the search button.
  - Search OMDb API for movies with the input text in the title.
  - Displays search results on the same page
  - Each movie in the search results has a link to a 'show' page

Show page:

  - Shows the results of a more detailed OMDb API search using the movie's name.
  - Displays all the details of the specific movie, including the poster image of the movie.


