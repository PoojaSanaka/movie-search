open the command window for the folder by right clicking it.
Then the cmd prompt will open.

command 1: npm init
(accept all defaults)
command 2: npm install --save http-server
command 3: node node_modules/http-server/bin/http-server

Connect browser to http://localhost:8080

For successful results search with keywords:Thor,Beauty,Iron.